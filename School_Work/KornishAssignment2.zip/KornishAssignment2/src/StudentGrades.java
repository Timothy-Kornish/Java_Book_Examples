
public class StudentGrades {

	public static void main(String[] args) {
		System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
		System.out.println("==          Student Grades          ==");
		System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///////////////////");
		System.out.println();
		System.out.println("Name\tLab\tBonus\tTotal");
		System.out.println("----\t---\t-----\t-----");
		System.out.println("Tony\t"+87+"\t"+7+"\t" +(87+7));
		System.out.println("Brenna\t"+82+"\t"+5+"\t"+(82+5));
		System.out.println("Will\t"+93+"\t"+0+"\t"+(93+0));
		System.out.println("Max\t"+73+"\t"+2+"\t"+(73+2));
		System.out.println("Kelsey\t"+80+"\t"+1+"\t"+(80+1));
	
	}

}
