
public class Names {

	public static void main(String[] args) {
		System.out.println(" \tName\t\tHometown\tMajor");
		System.out.println("\t====\t\t========\t=====");
		System.out.println("\tTimothy\t\tMissoula\tPhysics");
		System.out.println("\tJosh\t\tOrange County\tDesign");
		System.out.println("\tBrendon\t\tSalem\t\tPhysics");
		System.out.println("\tJessica\t\tBillngs\t\tPre-Med");
	}

}
